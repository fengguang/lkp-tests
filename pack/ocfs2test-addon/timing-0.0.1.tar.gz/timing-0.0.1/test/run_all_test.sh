python -m unittest discover -s ./ -p 'test_*.py' -v
